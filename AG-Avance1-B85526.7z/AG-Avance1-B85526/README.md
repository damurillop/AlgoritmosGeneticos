# AlgoritmosGeneticos
Repositorio para proyecto de algoritmos geneticos de IA.

Definiciones: 
    Individuo: conjunto de figuras. 
    Poblacion: conjunto de individuos. 
